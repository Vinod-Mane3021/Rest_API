package com.springrest.springrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringrestApplicationTests {

	@Test
	void contextLoads() {
	}

}
